import SwiftUI

var num1 = 300
var num2 = 20
var add = num1 + num2
var sub = num1 - num2
var mult = num1 * num2
var div = num1 / num2
print("\(num1) + \(num2) = \(add)")
print("\(num1) - \(num2) = \(sub)")
print("\(num1) * \(num2) = \(mult)")
print("\(num1) / \(num2) = \(div)")
